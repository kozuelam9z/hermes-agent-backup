# Skill Backup Infrastructure

## Two Independent Backup Systems (Separate Repos)

| | Skills Backup | Wiki Backup |
|---|---|---|
| **Repo** | `hermes-agent-backup` | `web3-payment-wiki` |
| **URL** | https://github.com/kozuelam9z/hermes-agent-backup | https://github.com/kozuelam9z/web3-payment-wiki |
| **Source** | `/opt/data/skills/` | `/opt/data/wiki/` |
| **Backup Dir** | `/opt/data/hermes-agent-backup/` | `/opt/data/wiki-backup/` |
| **Format** | tar.gz ONLY (no loose files) | Full file sync (all .md files) |
| **Schedule** | Hourly | 9am/1pm/5pm/9pm (4h) + 11pm (10h) |
| **Auth** | Classic PAT: `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` | Same PAT |

## Critical Rule: tar.gz Only for Skills

The skills repo must NEVER contain loose skill files. Only:
- `backup_YYYYMMDD_HHMMSS.tar.gz` — one per backup
- `README.md`
- `skill-monitor.sh` (the script, not the skills)

This was a user correction: skills backup should be a compressed archive, not a full directory sync.

## Cron Job IDs

| Job | Cron ID | Schedule |
|-----|---------|----------|
| `skill-backup-hourly` | (from cronjob creation) | `0 * * * *` |
| `wiki-backup-4h` | `921dab89e393` | `0 9,13,17,21 * * *` |
| `wiki-backup-10h` | `b6701fa09019` | `0 23 * * *` |

## GitHub Auth Setup

```bash
# Store classic PAT in ~/.netrc
echo "machine github.com
login kozuelam9z
password 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" > ~/.netrc
chmod 600 ~/.netrc
```

Both repos use HTTPS with embedded PAT. No SSH available on this system (`ssh` command not found).

## Scripts

- **Skills:** `/opt/data/scripts/skill-monitor.sh` — creates tar.gz, copies to repo dir, commits, pushes
- **Wiki:** `/opt/data/scripts/wiki-monitor.sh` — syncs wiki files to backup dir, commits, pushes

## Tested and Working

- Skills backup: verified push to `hermes-agent-backup` with 410 files in tar.gz
- Wiki backup: verified push to `web3-payment-wiki` with 10+ wiki files
- Duplicate detection: URL + SHA256 body hash comparison
- No truncation: raw sources stored in full, no ellipsis or `...` content