---
name: skill-backup
description: Monitor skills directory for new or modified skills, create backups, and push to GitHub. Triggers on skill creation/update, archives all skills, and syncs to https://github.com/kozuelam9z/hermes-agent-backup
triggers:
  - new skill created in /opt/data/skills/
  - skill modified or updated
  - manual trigger for full backup
  - new tool integrated into Hermes Agent
---

# Skill Backup & GitHub Sync

## Overview
This skill monitors `/opt/data/skills/` for changes, creates one compressed backup per day (date-only filename, overwrites hourly), and pushes to `https://github.com/kozuelam9z/hermes-agent-backup`.

**Critical: One backup per day.** Filename is `backup_YYYYMMDD.tar.gz` — date-only, no timestamp. Same file overwrites every run. Repo must never contain loose skill files or timestamped archives.

## Backup Process

### Step 1: Scan Skills Directory
```bash
SKILLS_DIR="/opt/data/skills"
BACKUP_DIR="/opt/data/skill-backups"

mkdir -p "$BACKUP_DIR"

# Count skills
SKILL_COUNT=$(find "$SKILLS_DIR" -name "SKILL.md" 2>/dev/null | wc -l)
echo "Found $SKILL_COUNT skills"
```

### Step 2: Create Backup Archive (tar.gz only, one per day)
```bash
SKILLS_DIR="/opt/data/skills"
BACKUP_DIR="/opt/data/skill-backups"

mkdir -p "$BACKUP_DIR"

# One backup per day — filename is date only, overwrites previous
TODAY=$(date +%Y%m%d)
BACKUP_FILE="${BACKUP_DIR}/backup_${TODAY}.tar.gz"

# Remove any previous backup for today (force fresh)
rm -f "$BACKUP_FILE"

tar -czf "$BACKUP_FILE" -C /opt/data skills/
echo "Created: backup_${TODAY}.tar.gz"
```

### Step 3: Copy tar.gz to Repo and Commit (overwrites same filename)
```bash
REPO_DIR="/opt/data/hermes-agent-backup"
cp "$BACKUP_FILE" "$REPO_DIR/"

# Write README using Python (avoids shell heredoc escaping issues with backticks)
python3 - "$TODAY" "$SKILL_COUNT" "$REPO_DIR" << 'PYEOF'
import sys
today = sys.argv[1]
count = sys.argv[2]
repo_dir = sys.argv[3]
readme = f"""# Hermes Agent Backup

Automated backup of all Hermes Agent skills and tools.

## Latest Backup
- **Date**: {today[:4]}-{today[4:6]}-{today[6:8]}
- **Skills**: {count} skill directories
- **File**: backup_{today}.tar.gz

## Backup Archives
One backup per day. Filename format: `backup_YYYYMMDD.tar.gz`

## Restore
```
tar -xzf backup_YYYYMMDD.tar.gz -C /opt/data
```

## Auto-Backup
Cron job runs hourly. One backup per day — same filename is overwritten daily and pushed to this repo automatically.
"""
with open(f"{repo_dir}/README.md", "w") as f:
    f.write(readme)
PYEOF
```

### Step 3: GitHub Push
Requires authentication (git credential helper, gh CLI, or token):
```bash
cd /opt/data/hermes-agent-backup
git add -A
git commit -m "Backup $(date +%Y-%m-%d\ %H:%M)"
git push origin main
```

## GitHub Authentication Setup
Use ONE of these methods:

### Classic PAT (Recommended)
Go to https://github.com/settings/tokens/new, select "Classic", check `☑ repo`, generate.
Works for: creating repos, pushing to any repo, full API access.

### Fine-Grained PAT (Limited)
Must be granted access to EACH repository individually via repo Settings → Collaborators.
CANNOT create new repos via API. Only works for repos explicitly authorized.
Symptoms of misconfiguration: `403 Write access denied` or `404 Not Found`.

### SSH Key
Works if `ssh` and `ssh-keygen` are available. No token needed.
```bash
ssh-keygen -t ed25519 -C "backup@hermes"
# Add public key to GitHub Settings → SSH keys
```

### git credential helper
```bash
git config --global credential.helper store
```

## Repo Must Exist First
With Fine-Grained PATs and SSH: **the repository must already exist on GitHub before pushing**.
Classic PATs can create repos via API:
```bash
curl -u USERNAME:TOKEN -X POST https://api.github.com/user/repos \
  -d '{"name":"hermes-agent-backup","private":false}'
```

## Cron Job for Monitoring (Optional)
Create a recurring cron to check every hour:
```bash
0 * * * * /opt/data/scripts/skill-monitor.sh
```

## Verification
```bash
git -C /opt/data/hermes-agent-backup log --oneline -5
```

For full infrastructure details (auth setup, current backup state, restore commands, relationship to wiki backup), see `references/skill-backup-infrastructure.md`.

## Pitfalls
- **Credentials missing at runtime**. The skill backed up locally but push fails with "could not read Username for 'https://github.com': No such device or address". Cause: `~/.netrc` or `$GITHUB_TOKEN` not present in the cron job environment. Fix: verify credentials exist BEFORE push (see Step 3 below).
- **Branch name mismatch**. If `git init` was run locally, it creates `master` branch by default. If the remote uses `main`, push to `master` fails with `refusing to fetch into branch...`. Fix: either `git push -u origin master:main` or rename local branch with `git branch -m master main` before push.
- **Fine-grained PAT + non-existent repo = 403 forever**. Fine-grained PATs cannot create repos via API, cannot clone non-existent repos, and require explicit per-repo grant. Symptoms: `remote: Write access to repository not granted`. Fix: create repo manually on github.com first, then grant access — OR use Classic PAT.
- **Fine-grained PAT + empty repo** = also 403. Even an empty existing repo still denies write unless explicitly granted access to that specific repo in repo Settings → Collaborators.
- **No SSH available** = SSH push fails. Check `which ssh` before attempting SSH-based push.
- **GitHub API repo creation** = only works with Classic PAT. Fine-grained PATs get `Resource not accessible by personal access token`.
- **Concurrent backups** → use lock file to prevent overlap
- **.netrc with PAT in URL** → security scanners flag it. Better to use credential helper or git config with token.
- **Wiki backup** → use separate repo (web3-payment-wiki) and separate cron jobs. Do NOT mix wiki files into skills backup repo.

## Step 3 Revised: Verify Credentials Before Push
```bash
# Check 1: ~/.netrc with PAT
if [ -f ~/.netrc ] && grep -q "github.com" ~/.netrc; then
    echo "Credentials: ~/.netrc found"
elif [ -n "$GITHUB_TOKEN" ]; then
    echo "Credentials: GITHUB_TOKEN env var found"
elif [ -n "$GIT_TOKEN" ]; then
    echo "Credentials: GIT_TOKEN env var found"
else
    echo "ERROR: No GitHub credentials found. Push will fail."
    echo "Set via: echo 'machine github.com login <USER> password <TOKEN>' > ~/.netrc && chmod 600 ~/.netrc"
    exit 1
fi

# Check 2: branch exists or will be created
git rev-parse --abbrev-ref HEAD  # should output master or main

# Check 3: remote reachable (optional, tests basic connectivity)
git ls-remote --heads origin main 2>/dev/null || git ls-remote --heads origin master 2>/dev/null || echo "Remote branch not found (will be created on first push)"
```

## Quick Start (Tested Flow)
```bash
# 1. Authenticate
git config --global credential.helper store
echo "machine github.com login <USER> password <TOKEN>" > ~/.netrc
chmod 600 ~/.netrc

# 2. Create local backup repo
mkdir -p /opt/data/hermes-agent-backup && cd /opt/data/hermes-agent-backup
git init && git config user.email "backup@hermes" && git config user.name "Hermes Backup"

# 3. Copy skills
cp -r /opt/data/skills/* .
cp /opt/data/skill-backups/*.tar.gz . 2>/dev/null
cp /opt/data/scripts/skill-monitor.sh . 2>/dev/null

# 4. Commit
git add -A && git commit -m "Backup $(date '+%Y-%m-%d')"

# 5. Push (repo must exist)
git remote add origin https://github.com/kozuelam9z/hermes-agent-backup.git
git push -u origin main
```