# Skill Backup Infrastructure

## Two Independent Backup Systems (Separate Repos)

| | Skills Backup | Wiki Backup |
|---|---|---|
| **Repo** | `hermes-agent-backup` | `web3-payment-wiki` |
| **URL** | https://github.com/kozuelam9z/hermes-agent-backup | https://github.com/kozuelam9z/web3-payment-wiki |
| **Source** | `/opt/data/skills/` | `/opt/data/wiki/` |
| **Backup Dir** | `/opt/data/hermes-agent-backup/` | `/opt/data/wiki-backup/` |
| **Format** | tar.gz ONLY — `backup_YYYYMMDD.tar.gz` (date-only, overwrites hourly, one per day) | Full file sync (all .md files) |
| **Schedule** | Hourly (same filename overwrites each run) | 9am/1pm/5pm/9pm (4h) + 11pm (10h) |
| **Auth** | Classic PAT: `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` | Same PAT |

## Critical Rules

**Skills repo:** Only `backup_YYYYMMDD.tar.gz` + `README.md` + `skill-monitor.sh`. Never loose skill files or timestamped archives. Filename is date-only (no timestamp), same file overwrites every hour.

**Wiki repo:** Full file sync of all wiki .md files, no archives.

**Separate repos — never mix.** User correction: two repos, two backup systems, completely independent.

## Cron Job IDs

| Job | Cron ID | Schedule |
|-----|---------|----------|
| `skill-backup-hourly` | (from cronjob creation) | `0 * * * *` |
| `wiki-backup-4h` | `921dab89e393` | `0 9,13,17,21 * * *` |
| `wiki-backup-10h` | `b6701fa09019` | `0 23 * * *` |

## GitHub Auth Setup

```bash
# Store classic PAT in ~/.netrc
echo "machine github.com
login kozuelam9z
password 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" > ~/.netrc
chmod 600 ~/.netrc
```

Both repos use HTTPS with embedded PAT. No SSH available on this system (`ssh` command not found).

## Runtime vs. Documented State

**The documented credentials in ~/.netrc may NOT be present at runtime** (e.g., cron jobs run as a different user or the file is not persisted). Always verify before push:
```bash
# Verify ~/.netrc exists and has content
cat ~/.netrc 2>/dev/null | grep -q "github.com" && echo "OK" || echo "MISSING"

# Verify token env var
[ -n "$GITHUB_TOKEN" ] && echo "GITHUB_TOKEN set" || echo "GITHUB_TOKEN not set"

# If missing: fail fast instead of trying push and getting cryptic error
[ -f ~/.netrc ] || { echo "ERROR: ~/.netrc missing"; exit 1; }
```

The skill-monitor.sh script should include this check before attempting `git push`.

## Scripts

- **Skills:** `/opt/data/scripts/skill-monitor.sh` — creates `backup_YYYYMMDD.tar.gz` (date-only), overwrites each hour, pushes to `hermes-agent-backup`
- **Wiki:** `/opt/data/scripts/wiki-monitor.sh` — syncs wiki files to backup dir, commits, pushes to `web3-payment-wiki`

## Tested and Working

- Skills backup: verified push to `hermes-agent-backup` with 104 skills in tar.gz, filename `backup_20260508.tar.gz`
- Wiki backup: verified push to `web3-payment-wiki` with 13 wiki pages
- Duplicate detection: URL + SHA256 body hash comparison
- No truncation: raw sources stored in full, no ellipsis or `...` content
- Language rules: Chinese source → Chinese content; English source → English + `## 中文摘要`
- Visual aids: ASCII for processes, Mermaid for complex flows, tables for comparisons