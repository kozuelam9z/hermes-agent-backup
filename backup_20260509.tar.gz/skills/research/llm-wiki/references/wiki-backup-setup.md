# Wiki Backup Infrastructure

## GitHub Repos

| Target | Repo | Auth |
|--------|------|------|
| Skills backup | https://github.com/kozuelam9z/hermes-agent-backup | Classic PAT `ghp_FyIuuaGq...` |
| Wiki backup | https://github.com/kozuelam9z/web3-payment-wiki | Classic PAT `ghp_FyIuuaGq...` |

## Scripts

| Script | Location | Purpose |
|--------|----------|---------|
| Skills backup | `/opt/data/scripts/skill-monitor.sh` | tar.gz of skills/, push to hermes-agent-backup |
| Wiki backup | `/opt/data/scripts/wiki-monitor.sh` | full file sync of wiki/, push to web3-payment-wiki |

## Backup Dirs

- Skills backup dir: `/opt/data/hermes-agent-backup/` (cloned from hermes-agent-backup)
- Wiki backup dir: `/opt/data/wiki-backup/` (cloned from web3-payment-wiki)

## Cron Jobs

| Job ID | Name | Schedule | Next Run |
|--------|------|----------|----------|
| `c5e6d5752255` | skill-backup-hourly | `0 * * * *` (hourly) | see cronjob list |
| `921dab89e393` | wiki-backup-4h | `0 9,13,17,21 * * *` | 9am, 1pm, 5pm, 9pm UTC |
| `b6701fa09019` | wiki-backup-10h | `0 23 * * *` | 11pm UTC (outside 9am-9pm window) |

## Authentication

Classic PAT stored in `~/.netrc`:
```
machine github.com
login kozuelam9z
password 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
```

## Manual Commands

```bash
# Manual skill backup
/opt/data/scripts/skill-monitor.sh

# Manual wiki backup
/opt/data/scripts/wiki-monitor.sh

# List cron jobs
cronjob list

# Pause/resume cron job
cronjob pause <job_id>
cronjob resume <job_id>
```

## Notes

- Skills backup uses **tar.gz only** (not full file sync)
- Wiki backup uses **full file sync** (all .md files)
- The two systems are completely independent — different cron jobs, different repos, different scripts
- Wiki backup runs 4x daily within 9am-9pm window (4h interval), and 1x outside (10h interval)