# WeChat Article Extraction — Working Recipe

## The Problem
`wechat-article-parser` library may fail to install (pip unavailable) or have API drift.
WeChat content is rendered client-side — simple `curl` returns empty `js_content` sections.

## Working Approach: Direct HTTP + Regex

```python
import urllib.request, re, html, hashlib

def fetch_wechat_article(url):
    """
    Fetch a WeChat public article and extract full content.
    Fallback when wechat-article-parser is unavailable.
    Returns dict with title, author, content (plain text), sha256.
    """
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    }

    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=20) as resp:
        html_content = resp.read().decode('utf-8', errors='replace')

    # Extract title — multiple fallback patterns
    title_patterns = [
        r'<title>([^<]+)</title>',
        r'"title":\s*"([^"]+)"',
        r'data-title="([^"]+)"',
    ]
    title = None
    for pat in title_patterns:
        m = re.search(pat, html_content)
        if m:
            title = m.group(1).strip()
            break
    if not title:
        title = 'Untitled'

    # Extract content from js_content div — must handle lazy-loaded content
    # WeChat wraps article body in id="js_content"
    content_patterns = [
        r'id="js_content"[^>]*>(.*?)</div>\s*<div[^>]*class="rich_media_extra"',
        r'id="js_content"[^>]*>(.*?)</div>\s*<div[^>]*id="js_',
        r'id="js_content"[^>]*>(.*?)</div>',
    ]
    raw_html = None
    for pat in content_patterns:
        m = re.search(pat, html_content, re.DOTALL)
        if m and len(m.group(1)) > 100:  # sanity check
            raw_html = m.group(1)
            break

    if not raw_html:
        # Fallback: find js_content by string search
        idx = html_content.find('id="js_content"')
        if idx > 0:
            start = html_content.find('>', idx) + 1
            end = html_content.find('</div>', start)
            raw_html = html_content[start:end]

    # Strip HTML tags, decode entities
    text = re.sub(r'<[^>]+>', ' ', raw_html) if raw_html else ''
    text = re.sub(r'\s+', ' ', text).strip()
    text = html.unescape(text)

    # Compute body SHA256 (exclude frontmatter when storing in raw/)
    body_sha256 = hashlib.sha256(text.encode('utf-8')).hexdigest()

    return {
        'title': title,
        'content': text,
        'content_len': len(text),
        'body_sha256': body_sha256,
    }

# Usage
result = fetch_wechat_article('https://mp.weixin.qq.com/s/UPe8YXfeemcDlpq4KopwvA')
print(f"Title: {result['title']}")
print(f"Length: {result['content_len']} chars")
print(f"Body SHA256: {result['body_sha256']}")
```

## Key Extraction Points

1. **User-Agent matters** — WeChat serves different content to different UAs. Use Chrome UA.
2. **`id="js_content"`** — the article body is always in this div. The div content is lazy-loaded JS, so the regex above catches the rendered version.
3. **Multiple fallback patterns** — WeChat changes HTML structure. Try patterns in order, sanity-check by length (>100 chars = likely real content).
4. **Body-only SHA256** — compute hash AFTER stripping HTML tags and frontmatter. When storing in `raw/`, put frontmatter above the body, compute hash on body only.
5. **No truncation** — store the full `text` in the raw/ file. No `...`, no `"...(continues)"`. The length can be 10K+ chars and that's fine.

## Storing in raw/

```python
import hashlib

url = 'https://mp.weixin.qq.com/s/...'
result = fetch_wechat_article(url)

# Build raw file content
raw_content = f'''---
source_url: {url}
ingested: 2026-05-08
sha256: {result['body_sha256']}
---

{result['content']}
'''

# Save
filename = 'raw/transcripts/filename-YYYY.md'
with open(filename, 'w', encoding='utf-8') as f:
    f.write(raw_content)
```

## What Doesn't Work
- `curl` without proper User-Agent → empty content
- `wechat-article-parser` library when pip unavailable
- Simple regex without `re.DOTALL` → misses multi-line content
- Computing SHA256 on the full file (including frontmatter) → wrong hash for drift detection
