# WeChat Article Extraction — Tested Recipe

## Status: Both library and stdlib fallback blocked by JS-rendering

**Tested:** 2026-05-09, Python 3.13.5, environment with pip installed.
**Finding:** WeChat now serves a JS-challenge page that requires a real browser. Both `wechat-article-parser` (httpx) and urllib/stdlib get a skeleton HTML with no `id="js_content"` div. This is NOT a code bug — it's WeChat blocking plain HTTP fetches.

## Library: `wechat-article-parser`

**Install:**
```bash
# pip not pre-installed on many environments — install first:
curl -sL https://bootstrap.pypa.io/get-pip.py | python3 - --break-system-packages
# installs to ~/.local/bin — call it directly:
~/.local/bin/pip3 install --break-system-packages git+https://github.com/huanjuedadehen/wechat-article-parser.git
```

**API (verified from source — docs are wrong):**
```python
from wechat_article_parser import WechatArticleParser  # NOT parse(url)!

parser = WechatArticleParser()
result = parser.parse(url)  # returns ArticleResult
```

**ArticleResult fields (from `models.py`):**
```python
# Account metadata
mp_id_b64, mp_id, mp_name, mp_alias, mp_image, mp_description
mp_account_type: AccountType  # AccountType.SUBSCRIPTION = "订阅号", .SERVICE = "服务号"

# Article metadata
article_id, article_msg_id, article_idx, article_sn
article_title, article_cover_image, article_description
article_markdown, article_publish_time  # Unix timestamp int
raw_html  # only populated if include_raw_html=True
images: list[str]
is_valid  # property — True only if ALL key fields present
```

**Key gotcha:** `is_valid` is a `@property` that returns True only when `mp_id, mp_name, article_id, article_msg_id, article_idx, article_sn, article_title, article_markdown, article_publish_time` are ALL non-empty. A mostly-parsed article with only some fields will still return `is_valid: False`.

**Known limitations:** Uses httpx internally (async under the hood). Fails on JS-challenge pages the same way urllib does — no browser engine.

## Stdlib Fallback: urllib + regex

Works when pip unavailable. Also blocked by JS-rendering but can still succeed on older or less-protected articles.

```python
import urllib.request, re, html, hashlib

def fetch_wechat_article(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    }
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=20) as resp:
        html_content = resp.read().decode('utf-8', errors='replace')

    title = re.search(r'<title>([^<]+)</title>', html_content)
    title = title.group(1).strip() if title else 'Untitled'

    patterns = [
        r'id="js_content"[^>]*>(.*?)(?:</div>\s*<div[^>]*class="rich_media_extra")',
        r'id="js_content"[^>]*>(.*?)(?:</div>\s*<div[^>]*id="js_")',
        r'id="js_content"[^>]*>(.*?)</div>',
    ]
    raw_html = None
    for pat in patterns:
        m = re.search(pat, html_content, re.DOTALL)
        if m and len(m.group(1)) > 100:
            raw_html = m.group(1)
            break

    if not raw_html:
        idx = html_content.find('id="js_content"')
        if idx > 0:
            start = html_content.find('>', idx) + 1
            end = html_content.find('</div>', start)
            raw_html = html_content[start:end]

    text = ''
    if raw_html:
        text = re.sub(r'<[^>]+>', ' ', raw_html)
        text = re.sub(r'\s+', ' ', text).strip()
        text = html.unescape(text)

    sha256 = hashlib.sha256(text.encode('utf-8')).hexdigest()
    return {'title': title, 'content': text, 'sha256': sha256}
```

## What DOESN'T work
- `curl` without proper UA → empty
- `wechat-article-parser` on JS-challenge pages (httpx has no JS engine)
- stdlib urllib → same block, no JS engine

## Real solutions for JS-blocked articles
1. **Headless browser** — Playwright/Selenium + Chrome. `node-electron-to-chromium` on this system but no browser binary. Run `agent-browser install` if available.
2. **Different IP** — WeChat rate-limits by IP. A proxy/VPN bypasses.
3. **Find the article elsewhere** — many WeChat articles get cross-posted.