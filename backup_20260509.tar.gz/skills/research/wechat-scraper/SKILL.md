---
name: wechat-scraper
description: Activates whenever a user provides a wechat article link
version: 1.0.0
category: research
---

## Overview
This skill provides a reusable approach to fetch and parse WeChat public account articles using the `wechat-article-parser` Python library.

## When to Use
- User shares a URL matching `https://mp.weixin.qq.com/s/*`
- Need to extract article text, title, author, publish time, and images.

## Steps
1. **Ensure the library is installed** (you can run this once):
   ```bash
   pip install git+https://github.com/huanjuedadehen/wechat-article-parser.git
   ```
2. **Parse the article**
   ```python
   from wechat_article_parser import parse

   article = parse(url)  # url is the WeChat article link
   ```
3. **Extract desired fields**
   - `article.title`
   - `article.author`
   - `article.publish_time`
   - `article.content` (HTML or plain text)
   - `article.images` (list of image URLs)
4. **Save to file** (optional)
   ```python
   with open('article.txt', 'w', encoding='utf-8') as f:
       f.write(f"Title: {article.title}\n")
       f.write(f"Author: {article.author}\n")
       f.write(f"Published: {article.publish_time}\n\n")
       f.write(article.content)
   ```
5. **Summarize** (if needed) – pass the extracted content to a summarization tool or LLM.

### Duplicate & Drift Check (before saving to wiki)
Before ingesting into a wiki, check for duplicates:

1. **URL duplicate check**: Scan existing raw files for `source_url: <this_url>` in frontmatter
2. **Content identical check**: Compare SHA256 of the new body against stored `sha256:` in the existing file
3. **Decision**:
   - SHA256 matches → skip (content unchanged, log as no-op)
   - SHA256 differs → update the raw file (drift detected), bump `ingested` date, update wiki pages citing this source
   - URL not found → proceed with normal ingestion

```python
# Duplicate check pseudo-code
import os, re, hashlib

def check_duplicate(url, new_body_sha256, raw_dir):
    for fname in os.listdir(raw_dir):
        fpath = os.path.join(raw_dir, fname)
        with open(fpath) as f:
            text = f.read()
        if f"source_url: {url}" in text:
            # Extract stored sha256 from frontmatter
            m = re.search(r'^sha256:\s*([a-f0-9]{64})', text, re.MULTILINE)
            stored_sha = m.group(1) if m else None
            if stored_sha == new_body_sha256:
                return 'duplicate'  # skip
            else:
                return 'drift'     # update
    return 'new'  # ingest

## Pitfalls
- **`pip` not always available** — many container/server environments lack pip. Always prepare a fallback: direct HTTP + regex extraction (see reference below).
- **Library API mismatch** — SKILL.md shows `parse(url)` but example.py uses `WechatArticleParser().parse()`. The library may not match its own docs. Verify before relying on either interface.
- **WeChat anti-scraping** — articles may render content client-side; curl alone often returns empty content sections. Requires careful regex targeting of `id="js_content"`.
- **Always respect copyright** of the original author's rights.
- **`wechat-article-parser` library is optional** — it may fail to install or have API drift. Do NOT block on it; prefer the direct extraction method below.
- **CRITICAL: Never truncate the raw source.** The raw/ file must contain the FULL content — no ellipsis `...`, no `"...(content continues)..."`, no `"..."`. If the article is long, store it completely anyway. Truncation defeats the purpose of drift-detection and source fidelity. The summary/diagram goes in the wiki page, not the raw source.

## Fallback: Direct HTTP + Regex Extraction
When the library fails or isn't available:

```python
import urllib.request, re, html, hashlib

def extract_wechat_article(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
    }
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=20) as resp:
        content = resp.read().decode('utf-8', errors='replace')

    # Extract title
    title = re.search(r'<title>([^<]+)</title>', content)
    title = title.group(1).strip() if title else 'Untitled'

    # Extract content from js_content div
    m = re.search(r'id="js_content"[^>]*>(.*?)</div>', content, re.DOTALL)
    if not m:
        # Try alternate pattern
        m = re.search(r'id="js_content"[^>]*>(.*?)(?:<div[^>]*id="js_|</div>\s*<div)', content, re.DOTALL)
    if m:
        text = re.sub(r'<[^>]+>', ' ', m.group(1))
        text = re.sub(r'\s+', ' ', text).strip()
        text = html.unescape(text)
    else:
        text = ''

    # Compute body sha256 for drift detection (immutable raw layer)
    sha256 = hashlib.sha256(text.encode('utf-8')).hexdigest()

    return {'title': title, 'content': text, 'sha256': sha256}
```

**Usage:**
```python
result = extract_wechat_article('https://mp.weixin.qq.com/s/...')
print(result['title'], result['content'][:500], result['sha256'])
```

## Verification
- Check that `content` length > 0
- Verify extracted title matches browser title
- Store `sha256` in raw source frontmatter for re-ingest drift detection

## Example
See `scripts/example.py` for a complete runnable script.

## Reference
See `references/wechat-extraction-recipe.md` for the working Python recipe (tested on this system, no pip required).