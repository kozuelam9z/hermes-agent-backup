---
name: wechat-scraper
description: Activates whenever a user provides a wechat article link
version: 3.0.0
category: research
---

## Overview
Fetches and parses WeChat public account articles. Ships with a self-contained script as the primary tool, with automatic fallback to the pip library when available.

**Tool chain (in order):**
1. `scripts/wechat_scraper.py` — stdlib-only, works everywhere. Imports and wraps `wechat-article-parser` if pip-installed, otherwise uses built-in stdlib fallback.
2. Inline regex fallback — only if the script itself fails catastrophically (rare)

## When to Use
- User shares a URL matching `https://mp.weixin.qq.com/s/*`
- Need to extract article text, title, author, publish time, images, and Markdown body

---

## Primary Tool: `scripts/wechat_scraper.py`

Zero-dependency stdlib script. Automatically uses `wechat-article-parser` if pip-installed, otherwise falls back to built-in stdlib extraction. Output is Markdown with YAML frontmatter.

**API — `parse(url)` returns `ArticleResult` dataclass:**
```python
from scripts.wechat_scraper import parse

result = parse("https://mp.weixin.qq.com/s/xxxxx")
# result.title, result.author, result.publish_time, result.description
# result.markdown       # clean Markdown body ✨
# result.raw_html       # original HTML (if library used)
# result.images         # list of image URLs
# result.body_sha256    # SHA256 of markdown body (for drift detection)
# result.is_valid       # all key fields parsed successfully
# result.to_markdown()  # full Markdown file with YAML frontmatter
```

**CLI — output is pure Markdown with frontmatter:**
```bash
python3 scripts/wechat_scraper.py <url>             # stdout
python3 scripts/wechat_scraper.py <url> output.md   # save to file
```

**`ArticleResult` fields** (mirrors `wechat-article-parser`'s `ArticleResult`):
```
source_url, mp_name, mp_alias, mp_description, mp_account_type
article_id, article_msg_id, article_idx, article_sn
title, cover_image, description, author
publish_time, publish_timestamp
markdown, raw_html, images
body_sha256, is_valid
to_markdown()   # render full Markdown file
```

### Architecture notes
- `parse()` tries `wechat-article-parser` first; falls back to stdlib on ImportError
- Multiple regex patterns per field — WeChat changes HTML structure frequently
- Chrome User-Agent string to avoid early blocking
- `body_sha256` computed on markdown body only (excludes frontmatter) for drift detection
- Image URLs deduplicated; icons/avatars/tracking pixels filtered out
- Output is Markdown-first (via `to_markdown()`), not plain text

---

## Stdlib Fallback (inside the script)

When `wechat-article-parser` is not pip-installed, the script uses a built-in stdlib-only extractor. This path uses urllib + regex — no pip, no browser required.

The fallback handles WeChat's JS-rendered content by looking for `id="js_content"` and similar structural markers in the raw HTML.

**If content returns empty despite using the script:** WeChat is serving a JS-challenge page that requires a real browser session. This is not a code bug. Try: use a headless browser, a different IP/proxy, or find the article on another platform.

When the script itself fails to run (not just returns empty content), use this inline fallback. This is NOT needed when the script runs but returns empty — that case is handled by the stdlib fallback inside the script.

```python
import urllib.request, re, html, hashlib

def fetch_wechat_article(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
    }
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=20) as resp:
        html_content = resp.read().decode('utf-8', errors='replace')

    title = re.search(r'<title>([^<]+)</title>', html_content)
    title = title.group(1).strip() if title else 'Untitled'

    m = re.search(r'id="js_content"[^>]*>(.*?)</div>', html_content, re.DOTALL)
    if not m:
        m = re.search(r'id="js_content"[^>]*>(.*?)(?:<div[^>]*id="js_|</div>\s*<div)', html_content, re.DOTALL)
    text = ''
    if m:
        text = re.sub(r'<[^>]+>', ' ', m.group(1))
        text = re.sub(r'\s+', ' ', text).strip()
        text = html.unescape(text)

    sha256 = hashlib.sha256(text.encode('utf-8')).hexdigest()
    return {'title': title, 'content': text, 'sha256': sha256}
```

> **Empty content = WeChat JS-challenge page.** urllib/httpx cannot bypass WeChat's client-side rendering. The script handles this gracefully (returns empty, exits 1) but cannot fix it. Use a headless browser or different IP.

---

## Duplicate & Drift Check (before saving to wiki)

1. **URL duplicate check**: Scan existing raw files for `source_url: <this_url>` in frontmatter
2. **Content identical check**: Compare SHA256 of new body against stored `sha256:` in the existing file
3. **Decision**:
   - SHA256 matches → skip (unchanged, log as no-op)
   - SHA256 differs → update raw file (drift detected), bump `ingested` date
   - URL not found → proceed with normal ingestion

```python
import os, re, hashlib

def check_duplicate(url, new_body_sha256, raw_dir):
    for fname in os.listdir(raw_dir):
        fpath = os.path.join(raw_dir, fname)
        with open(fpath) as f:
            text = f.read()
        if f"source_url: {url}" in text:
            m = re.search(r'^sha256:\s*([a-f0-9]{64})', text, re.MULTILINE)
            stored_sha = m.group(1) if m else None
            if stored_sha == new_body_sha256:
                return 'duplicate'
            else:
                return 'drift'
    return 'new'
```

## Pitfalls

- **WeChat JS-rendering wall:** WeChat increasingly serves a challenge page that requires a real browser session — urllib/httpx get a skeleton HTML with no `id="js_content"`. Empty content is NOT a code bug. This affects both the stdlib fallback and `wechat-article-parser` (both use plain HTTP). Fix: use a headless browser, a different IP/proxy, or find the article on another platform.
- **pip not pre-installed on many environments:** Python 3.13+ and minimal containers often ship without pip. Workaround: `curl -sL https://bootstrap.pypa.io/get-pip.py | python3 - --break-system-packages`. pip installs to `~/.local/bin` — add to PATH or call `~/.local/bin/pip3` directly.
- **`wechat-article-parser` docs are wrong:** The README shows `parse(url)` but the actual API is `WechatArticleParser().parse()`. Always check the actual library code (`site-packages/wechat_article_parser/parser.py`) rather than trusting the docs.
- **CRITICAL: Never truncate the raw source.** No `...`, no `"...(content continues)..."`. Store the full text. Truncation defeats drift-detection and source fidelity. Summary/diagram go in the wiki page, not the raw file.
- **`body_sha256` computed on body only** — compute AFTER stripping HTML tags and frontmatter. Hashing the full file would break drift detection.
- **AccountType enum is a string Enum:** `AccountType.SUBSCRIPTION` has value `"订阅号"`, not `"SUBSCRIPTION"`. When mapping to a string field, use `.value` or compare directly.

## Supported Scripts
| Script | Dependencies | Notes |
|--------|-------------|-------|
| `scripts/wechat_scraper.py` | stdlib only (auto-uses pip lib if available) | **Primary tool.** `parse(url)` → `ArticleResult`, `to_markdown()` |
| `scripts/example.py` | pip (wechat-article-parser) | Original library-based example — still valid reference |

## Reference
- `references/wechat-extraction-recipe.md` — stdlib fallback code + WeChat HTML structure notes (tested on this system)
- `scripts/wechat_scraper.py` — primary tool, auto-falls back
- `scripts/example.py` — pip library-based example (higher success on JS-blocked articles)

## Verification
- `content` length > 0
- Extracted title matches browser title
- `body_sha256` stored in raw source frontmatter
- If content empty → WeChat blocked, try pip library or headless browser