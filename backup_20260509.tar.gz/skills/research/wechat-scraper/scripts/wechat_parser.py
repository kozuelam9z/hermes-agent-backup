#!/usr/bin/env python3
"""
WeChat Article Parser — Markdown-first.

Auto-installs pip + wechat-article-parser if missing, then uses the library
to produce clean Markdown. Falls back to stdlib (urllib + regex) when the
library can't be installed.

Usage — as library:
    from wechat_parser import parse, parse_async
    result = parse("https://mp.weixin.qq.com/s/xxxxx")
    # result.title, result.markdown, result.author, etc.
    print(result.to_markdown())

Usage — CLI:
    python wechat_parser.py <url> [output_file.md]
"""

import sys
import os
import re
import html
import hashlib
import urllib.request
from dataclasses import dataclass, field
from typing import Optional

# ─────────────────────────────────────────────────────────────────────────────
# Bootstrap: auto-install pip + wechat-article-parser if not present
# ─────────────────────────────────────────────────────────────────────────────

def _bootstrap():
    """Install pip then wechat-article-parser if not already importable."""
    try:
        __import__("wechat_article_parser")
        return  # already available
    except ImportError:
        pass

    print("[bootstrap] wechat-article-parser not found, installing...", file=sys.stderr)

    # 1. Install pip
    pip_path = '/opt/data/home/.local/bin/pip3'
    if not os.path.exists(pip_path):
        import urllib.request as _urllib
        _urllib.request.urlretrieve('https://bootstrap.pypa.io/get-pip.py',
                                   '/tmp/get-pip.py')
        import subprocess
        subprocess.run([sys.executable, '/tmp/get-pip.py',
                        '--break-system-packages', '--quiet'], check=True)
        # Refresh sys.path so newly installed packages are findable
        import importlib
        importlib.invalidate_caches()

    # 2. Install wechat-article-parser
    import subprocess
    subprocess.run(
        [pip_path, 'install', '--break-system-packages', '--quiet',
         'git+https://github.com/huanjuedadehen/wechat-article-parser.git'],
        check=True,
    )
    # Refresh import caches
    import importlib
    importlib.invalidate_caches()
    print("[bootstrap] installation complete", file=sys.stderr)


# ─────────────────────────────────────────────────────────────────────────────
# Dataclass — mirrors wechat-article-parser's ArticleResult fields
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ArticleResult:
    """Unified result type regardless of which parser is used."""
    source_url: str = ''
    mp_name: str = ''
    mp_alias: str = ''
    mp_description: str = ''
    mp_account_type: str = ''

    article_id: str = ''
    article_msg_id: int = 0
    article_idx: int = 0
    article_sn: str = ''
    title: str = ''
    cover_image: str = ''
    description: str = ''
    author: str = ''
    publish_time: str = ''
    publish_timestamp: int = 0

    markdown: str = ''
    raw_html: str = ''
    images: list = field(default_factory=list)

    body_sha256: str = ''
    is_valid: bool = False

    def to_markdown(self) -> str:
        """Render as a Markdown file with YAML frontmatter."""
        lines = [
            '---',
            f'source_url: {self.source_url}',
            f'mp_name: {self.mp_name}',
            f'mp_alias: {self.mp_alias}',
            f'author: {self.author}',
            f'publish_time: {self.publish_time}',
            f'publish_timestamp: {self.publish_timestamp}',
            f'title: {self.title}',
            f'description: {self.description}',
            f'cover_image: {self.cover_image}',
            f'images_count: {len(self.images)}',
            f'body_sha256: {self.body_sha256}',
            f'is_valid: {self.is_valid}',
            '---',
            '',
            f'# {self.title}',
            '',
        ]
        if self.author:
            lines.append(f'*By {self.author}*')
            lines.append('')
        if self.publish_time:
            lines.append(f'Published: {self.publish_time}')
            lines.append('')
        if self.cover_image:
            lines.append(f'![cover]({self.cover_image})')
            lines.append('')

        lines.append(self.markdown.strip())
        lines.append('')

        if self.images:
            lines.append('---')
            lines.append('')
            lines.append('## Images')
            lines.append('')
            for i, img_url in enumerate(self.images, 1):
                lines.append(f'[{i}]({img_url})')
            lines.append('')

        return '\n'.join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Primary: wechat-article-parser (pip-installed)
# ─────────────────────────────────────────────────────────────────────────────

def _parse_via_library(url: str) -> Optional[ArticleResult]:
    """Parse using wechat-article-parser. Return None if unavailable/failed."""
    try:
        from wechat_article_parser import parse as lib_parse, AccountType
    except ImportError:
        return None

    try:
        result = lib_parse(url, include_raw_html=True)

        at_map = {
            AccountType.SUBSCRIPTION: 'SUBSCRIPTION',
            AccountType.SERVICE: 'SERVICE',
            AccountType.UNKNOWN: 'UNKNOWN',
        }

        return ArticleResult(
            source_url=url,
            mp_name=result.mp_name,
            mp_alias=result.mp_alias,
            mp_description=result.mp_description,
            mp_account_type=at_map.get(result.mp_account_type, 'UNKNOWN'),
            article_id=str(result.article_id) if result.article_id else '',
            article_msg_id=result.article_msg_id or 0,
            article_idx=result.article_idx or 0,
            article_sn=result.article_sn or '',
            title=result.article_title or '',
            cover_image=result.article_cover_image or '',
            description=result.article_description or '',
            author=result.mp_name,
            publish_time=_format_ts(result.article_publish_time),
            publish_timestamp=result.article_publish_time or 0,
            markdown=result.article_markdown or '',
            raw_html=result.raw_html or '',
            images=result.images or [],
            body_sha256=hashlib.sha256(
                (result.article_markdown or '').encode('utf-8')
            ).hexdigest(),
            is_valid=result.is_valid,
        )
    except Exception as e:
        print(f"[library] error: {e}", file=sys.stderr)
        return None


# ─────────────────────────────────────────────────────────────────────────────
# Fallback: stdlib-only (urllib + regex)
# ─────────────────────────────────────────────────────────────────────────────

_CHROME_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/120.0.0.0 Safari/537.36'
)


def _parse_via_stdlib(url: str) -> ArticleResult:
    """Stdlib-only parse (no pip required)."""
    result = ArticleResult(source_url=url)

    req = urllib.request.Request(url, headers={
        'User-Agent': _CHROME_UA,
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    })
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            raw_html = resp.read().decode('utf-8', errors='replace')
    except Exception as e:
        print(f"[stdlib] fetch error: {e}", file=sys.stderr)
        return result

    if not raw_html:
        return result

    # Title
    for pat in [
        r'<title>([^<]+)</title>',
        r'"title":\s*"([^"]+)"',
        r'data-title="([^"]+)"',
    ]:
        m = re.search(pat, raw_html)
        if m:
            result.title = html.unescape(m.group(1).strip())
            break
    if not result.title:
        result.title = 'Untitled'

    # Author
    for pat in [
        r'id="js_name"[^>]*>([^<]+)</span>',
        r'class="rich_media_meta[^"]*">([^<]+)</(?:span|a)',
        r'"author":\s*"([^"]+)"',
    ]:
        m = re.search(pat, raw_html)
        if m:
            result.author = html.unescape(m.group(1).strip())
            break

    # Publish time
    for pat in [
        r'class="rich_media_meta[^"]*rich_media_meta_text[^"]*">([^<]+)</span>',
        r'<em id="publish_time">([^<]+)</em>',
        r'"publish_time":\s*"([^"]+)"',
    ]:
        m = re.search(pat, raw_html)
        if m:
            result.publish_time = html.unescape(m.group(1).strip())
            break

    # Description
    for pat in [
        r'id="js_snippet"[^>]*>([^<]+)</p>',
        r'"digest":\s*"([^"]+)"',
        r'name="description" content="([^"]+)"',
    ]:
        m = re.search(pat, raw_html)
        if m:
            result.description = html.unescape(m.group(1).strip())
            break

    # Cover image
    m = re.search(
        r'id="js_content"[^>]*background-image:\s*url\([\'"]?([^\'"<>]+)[\'"]?\)', raw_html)
    if not m:
        m = re.search(r'<img[^>]+id="js_cover"[^>]+src="([^"]+)"', raw_html)
    if not m:
        m = re.search(r'"cover_image":\s*"([^"]+)"', raw_html)
    if m:
        result.cover_image = m.group(1).strip()

    # Content
    content_html, plain_text = _extract_content_stdlib(raw_html)
    result.markdown = _plain_text_to_markdown(plain_text)
    result.raw_html = content_html

    # Images
    result.images = _extract_images_stdlib(raw_html)

    # SHA256 & validity
    result.body_sha256 = hashlib.sha256(
        result.markdown.encode('utf-8')
    ).hexdigest()
    result.is_valid = len(result.markdown) > 100

    return result


def _extract_content_stdlib(html_content: str) -> tuple[str, str]:
    patterns = [
        r'id="js_content"[^>]*>(.*?)(?:</div>\s*<div[^>]*class="rich_media_extra")',
        r'id="js_content"[^>]*>(.*?)(?:</div>\s*<div[^>]*id="js_")',
        r'id="js_content"[^>]*>(.*?)</div>',
    ]
    raw_html = None
    for pat in patterns:
        m = re.search(pat, html_content, re.DOTALL)
        if m and len(m.group(1)) > 100:
            raw_html = m.group(1)
            break

    if not raw_html:
        idx = html_content.find('id="js_content"')
        if idx > 0:
            start = html_content.find('>', idx) + 1
            end = html_content.find('</div>', start)
            raw_html = html_content[start:end]

    if not raw_html:
        return '', ''

    text = re.sub(r'<[^>]+>', ' ', raw_html)
    text = re.sub(r'\s+', ' ', text).strip()
    text = html.unescape(text)

    return raw_html.strip(), text


def _plain_text_to_markdown(text: str) -> str:
    """Convert stripped plain text to readable Markdown."""
    if not text:
        return ''
    text = text.replace('\r\n', '\n').replace('\r', '\n')
    paras = text.split('\n\n')
    result = []
    for para in paras:
        para = para.strip()
        if not para or len(para) < 10:
            continue
        if re.match(r'^[\u25a0\u25b6\u2022\u2023\u25e6•\-–]\s', para) or \
           re.match(r'^\d+[．.、]\s', para):
            result.append(para)
            continue
        para = re.sub(r'(?<![\]\)])(https?://[^\s\)]+)', r'[\1](\1)', para)
        if '|' in para and para.count('|') >= 3:
            lines = [
                '  '.join(c.strip() for c in line.strip('|').split('|'))
                for line in para.split('\n')
            ]
            para = '\n'.join(lines)
        result.append(para)
    return '\n\n'.join(result)


def _extract_images_stdlib(html_content: str) -> list:
    patterns = [
        r'<img[^>]+src="([^"]+)"[^>]*>',
        r'"url":\s*"([^"]+)"',
        r'data-src="([^"]+)"',
    ]
    seen = set()
    images = []
    for pat in patterns:
        for m in re.finditer(pat, html_content):
            url = m.group(1).strip()
            if url.startswith('http') and url not in seen and not any(
                x in url for x in
                ['spm/', 'mmbiz Icons', 'avatar', 'logging', 'error-legacy']
            ):
                seen.add(url)
                images.append(url)
    return images


def _format_ts(ts: int) -> str:
    if not ts:
        return ''
    try:
        from datetime import datetime, timezone
        return datetime.fromtimestamp(ts, tz=timezone.utc).strftime('%Y-%m-%d %H:%M:%S')
    except Exception:
        return str(ts)


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def parse(url: str) -> ArticleResult:
    """
    Parse a WeChat article URL and return an ArticleResult.

    Tries wechat-article-parser first. If unavailable, falls back to
    the stdlib-only implementation (urllib + regex).
    """
    # Auto-bootstrap if library missing
    try:
        __import__("wechat_article_parser")
    except ImportError:
        _bootstrap()

    # Try library first
    article = _parse_via_library(url)
    if article is not None:
        return article

    # Fallback to stdlib
    print("[stdlib] falling back to urllib+regex parser", file=sys.stderr)
    return _parse_via_stdlib(url)


async def parse_async(url: str) -> ArticleResult:
    """Async wrapper."""
    return parse(url)


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────

def main():
    if len(sys.argv) < 2:
        print("Usage: python wechat_parser.py <wechat_article_url> [output_file.md]")
        sys.exit(1)

    url = sys.argv[1]
    output_file = sys.argv[2] if len(sys.argv) > 2 else None

    print(f"Fetching: {url}", file=sys.stderr)
    result = parse(url)

    if not result.is_valid and not result.markdown:
        print("Error: could not extract article content", file=sys.stderr)
        sys.exit(1)

    # Summary to stderr
    print(f"Title: {result.title}", file=sys.stderr)
    print(f"Author: {result.author}", file=sys.stderr)
    print(f"Published: {result.publish_time}", file=sys.stderr)
    print(f"Markdown: {len(result.markdown)} chars", file=sys.stderr)
    print(f"Images: {len(result.images)}", file=sys.stderr)
    print(f"Valid: {result.is_valid}", file=sys.stderr)

    # Markdown to stdout
    print(result.to_markdown())

    if output_file:
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(result.to_markdown())
        print(f"\nSaved to: {output_file}", file=sys.stderr)


if __name__ == '__main__':
    main()