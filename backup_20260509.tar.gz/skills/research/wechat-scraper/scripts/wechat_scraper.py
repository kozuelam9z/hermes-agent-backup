#!/usr/bin/env python3
"""
WeChat Article Scraper — Markdown-first edition.

Tries `wechat-article-parser` first (gives clean article_markdown),
falls back to a stdlib-only implementation when pip unavailable.

Usage — as library:
    from wechat_scraper import parse, parse_async
    result = parse("https://mp.weixin.qq.com/s/xxxxx")
    # result.title, result.markdown, result.author, etc.

Usage — CLI:
    python wechat_scraper.py <url> [output_file.md]
    python wechat_scraper.py "https://mp.weixin.qq.com/s/xxxxx" article.md

Output is Markdown with YAML frontmatter.
"""

import sys
import os
import re
import html
import hashlib
import asyncio
import urllib.request
from dataclasses import dataclass, field
from typing import Optional

# ─────────────────────────────────────────────────────────────────────────────
# Dataclass — mirrors wechat-article-parser's ArticleResult fields
# (also works as the fallback when the library isn't installed)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ArticleResult:
    """Unified result type regardless of which parser is used."""
    # Source metadata
    source_url: str = ''
    mp_name: str = ''
    mp_alias: str = ''
    mp_description: str = ''
    mp_account_type: str = ''          # SUBSCRIPTION / SERVICE / UNKNOWN

    # Article metadata
    article_id: str = ''
    article_msg_id: int = 0
    article_idx: int = 0
    article_sn: str = ''
    title: str = ''
    cover_image: str = ''
    description: str = ''              # summary / digest
    author: str = ''
    publish_time: str = ''             # human-readable, e.g. "2026-05-09"
    publish_timestamp: int = 0         # Unix timestamp (0 if unknown)

    # Content
    markdown: str = ''                 # ✨ clean Markdown body
    raw_html: str = ''
    images: list = field(default_factory=list)

    # Utility
    body_sha256: str = ''              # SHA256 of markdown body (for drift check)
    is_valid: bool = False

    def to_markdown(self) -> str:
        """Render as a Markdown file with YAML frontmatter."""
        lines = [
            '---',
            f'source_url: {self.source_url}',
            f'mp_name: {self.mp_name}',
            f'mp_alias: {self.mp_alias}',
            f'author: {self.author}',
            f'publish_time: {self.publish_time}',
            f'publish_timestamp: {self.publish_timestamp}',
            f'title: {self.title}',
            f'description: {self.description}',
            f'cover_image: {self.cover_image}',
            f'images_count: {len(self.images)}',
            f'body_sha256: {self.body_sha256}',
            f'is_valid: {self.is_valid}',
            '---',
            '',
            f'# {self.title}',
            '',
        ]
        if self.author:
            lines.append(f'*By {self.author}*')
            lines.append('')
        if self.publish_time:
            lines.append(f'Published: {self.publish_time}')
            lines.append('')

        # Add cover image if available
        if self.cover_image:
            lines.append(f'![cover]({self.cover_image})')
            lines.append('')

        # Markdown body
        lines.append(self.markdown.strip())
        lines.append('')

        # Image gallery (if any)
        if self.images:
            lines.append('')
            lines.append('---')
            lines.append('')
            lines.append('## Images')
            lines.append('')
            for i, img_url in enumerate(self.images, 1):
                lines.append(f'[{i}]({img_url})')
            lines.append('')

        return '\n'.join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Primary: use wechat-article-parser (pip-installed)
# ─────────────────────────────────────────────────────────────────────────────

def _try_library_parse(url: str) -> Optional[ArticleResult]:
    """Attempt to parse via wechat-article-parser. Return None on failure."""
    try:
        from wechat_article_parser import parse as lib_parse, AccountType

        result = lib_parse(url)

        # Map library's AccountType enum to string
        at_map = {
            AccountType.SUBSCRIPTION: 'SUBSCRIPTION',
            AccountType.SERVICE: 'SERVICE',
            AccountType.UNKNOWN: 'UNKNOWN',
        }

        article = ArticleResult(
            source_url=url,
            mp_name=result.mp_name,
            mp_alias=result.mp_alias,
            mp_description=result.mp_description,
            mp_account_type=at_map.get(result.mp_account_type, 'UNKNOWN'),
            article_id=str(result.article_id) if result.article_id else '',
            article_msg_id=result.article_msg_id or 0,
            article_idx=result.article_idx or 0,
            article_sn=result.article_sn or '',
            title=result.article_title or '',
            cover_image=result.article_cover_image or '',
            description=result.article_description or '',
            author=result.mp_name,        # library puts author in mp_name for og
            publish_time=_format_time(result.article_publish_time),
            publish_timestamp=result.article_publish_time or 0,
            markdown=result.article_markdown or '',
            raw_html=result.raw_html or '',
            images=result.images or [],
            body_sha256=hashlib.sha256(
                (result.article_markdown or '').encode('utf-8')
            ).hexdigest(),
            is_valid=result.is_valid,
        )
        return article
    except ImportError:
        return None
    except Exception as e:
        print(f"[wechat-article-parser] error: {e}", file=sys.stderr)
        return None


# ─────────────────────────────────────────────────────────────────────────────
# Fallback: stdlib-only parser (no pip required)
# ─────────────────────────────────────────────────────────────────────────────

def _fallback_parse(url: str) -> ArticleResult:
    """Parse using only stdlib (urllib, re, html). Used when pip unavailable."""
    CHROME_UA = (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/120.0.0.0 Safari/537.36'
    )

    result = ArticleResult(source_url=url)

    # Fetch
    req = urllib.request.Request(url, headers={
        'User-Agent': CHROME_UA,
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    })
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            raw_html = resp.read().decode('utf-8', errors='replace')
    except Exception as e:
        print(f"Fetch error: {e}", file=sys.stderr)
        return result

    if not raw_html:
        return result

    # ── Title ──────────────────────────────────────────────────────────────
    for pat in [
        r'<title>([^<]+)</title>',
        r'"title":\s*"([^"]+)"',
        r'data-title="([^"]+)"',
    ]:
        m = re.search(pat, raw_html)
        if m:
            result.title = html.unescape(m.group(1).strip())
            break
    if not result.title:
        result.title = 'Untitled'

    # ── Author ────────────────────────────────────────────────────────────
    for pat in [
        r'id="js_name"[^>]*>([^<]+)</span>',
        r'class="rich_media_meta[^"]*">([^<]+)</(?:span|a)',
        r'"author":\s*"([^"]+)"',
    ]:
        m = re.search(pat, raw_html)
        if m:
            result.author = html.unescape(m.group(1).strip())
            break

    # ── Publish time ───────────────────────────────────────────────────────
    for pat in [
        r'class="rich_media_meta[^"]*rich_media_meta_text[^"]*">([^<]+)</span>',
        r'<em id="publish_time">([^<]+)</em>',
        r'"publish_time":\s*"([^"]+)"',
    ]:
        m = re.search(pat, raw_html)
        if m:
            result.publish_time = html.unescape(m.group(1).strip())
            break

    # ── Description / Digest ──────────────────────────────────────────────
    for pat in [
        r'id="js_snippet"[^>]*>([^<]+)</p>',
        r'"digest":\s*"([^"]+)"',
        r'name="description" content="([^"]+)"',
    ]:
        m = re.search(pat, raw_html)
        if m:
            result.description = html.unescape(m.group(1).strip())
            break

    # ── Cover image ───────────────────────────────────────────────────────
    m = re.search(r'id="js_content"[^>]*background-image:\s*url\([\'"]?([^\'"<>]+)[\'"]?\)', raw_html)
    if not m:
        m = re.search(r'<img[^>]+id="js_cover"[^>]+src="([^"]+)"', raw_html)
    if not m:
        m = re.search(r'"cover_image":\s*"([^"]+)"', raw_html)
    if m:
        result.cover_image = m.group(1).strip()

    # ── Content extraction ────────────────────────────────────────────────
    content_html, plain_text = _extract_content_stdlib(raw_html)

    # ── Convert plain text → Markdown ─────────────────────────────────────
    result.markdown = _plain_text_to_markdown(plain_text)
    result.raw_html = content_html

    # ── Images ─────────────────────────────────────────────────────────────
    result.images = _extract_images(raw_html)

    # ── SHA256 & validity ──────────────────────────────────────────────────
    result.body_sha256 = hashlib.sha256(result.markdown.encode('utf-8')).hexdigest()
    result.is_valid = len(result.markdown) > 100

    return result


def _extract_content_stdlib(html_content: str) -> tuple[str, str]:
    """Extract (raw_html, plain_text) from js_content div."""
    patterns = [
        r'id="js_content"[^>]*>(.*?)(?:</div>\s*<div[^>]*class="rich_media_extra")',
        r'id="js_content"[^>]*>(.*?)(?:</div>\s*<div[^>]*id="js_")',
        r'id="js_content"[^>]*>(.*?)</div>',
    ]
    raw_html = None
    for pat in patterns:
        m = re.search(pat, html_content, re.DOTALL)
        if m and len(m.group(1)) > 100:
            raw_html = m.group(1)
            break

    if not raw_html:
        idx = html_content.find('id="js_content"')
        if idx > 0:
            start = html_content.find('>', idx) + 1
            end = html_content.find('</div>', start)
            raw_html = html_content[start:end]

    if not raw_html:
        return '', ''

    # Strip tags, decode entities
    text = re.sub(r'<[^>]+>', ' ', raw_html)
    text = re.sub(r'\s+', ' ', text).strip()
    text = html.unescape(text)

    return raw_html.strip(), text


def _plain_text_to_markdown(text: str) -> str:
    """
    Convert plain-ish text to clean Markdown.
    Handles paragraphs, line breaks, bold/italic markers, and inline code.
    """
    if not text:
        return ''

    # Normalize line breaks first
    text = text.replace('\r\n', '\n').replace('\r', '\n')

    # Split into paragraphs (double newline)
    # First normalize any single \n that follows a sentence-ending punct to a double
    # This is conservative — we prefer over-splitting to under-splitting
    paras = text.split('\n\n')

    result_paras = []
    for para in paras:
        para = para.strip()
        if not para:
            continue

        # Skip obvious navigation/boilerplate lines
        if len(para) < 10 or para in ('|', '—', '–', '*', '#'):
            continue

        # Detect list items
        if re.match(r'^[\u25a0\u25b6\u2022\u2023\u25e6•\-–]\s', para) or \
           re.match(r'^\d+[．.、]\s', para):
            result_paras.append(para)
            continue

        # Wrap block-level bare URLs as links
        para = re.sub(
            r'(?<![\]\)])(https?://[^\s\)]+)',
            r'[\1](\1)',
            para
        )

        # Convert | table syntax → text lines (remove pipes for readability)
        if '|' in para and para.count('|') >= 3:
            lines = para.split('\n')
            cleaned = []
            for line in lines:
                cells = [c.strip() for c in line.strip('|').split('|')]
                cleaned.append('  '.join(cells))
            para = '\n'.join(cleaned)

        result_paras.append(para)

    return '\n\n'.join(result_paras)


def _extract_images(html_content: str) -> list:
    """Harvest image URLs from the HTML."""
    patterns = [
        r'<img[^>]+src="([^"]+)"[^>]*>',
        r'"url":\s*"([^"]+)"',
        r'data-src="([^"]+)"',
    ]
    seen = set()
    images = []
    for pat in patterns:
        for m in re.finditer(pat, html_content):
            url = m.group(1).strip()
            if url.startswith('http') and url not in seen and not any(
                x in url for x in ['spm/', 'mmbiz Icons', 'avatar', 'logging', 'error-legacy']
            ):
                seen.add(url)
                images.append(url)
    return images


def _format_time(timestamp: int) -> str:
    """Convert Unix timestamp to human-readable string."""
    if not timestamp:
        return ''
    try:
        from datetime import datetime, timezone
        dt = datetime.fromtimestamp(timestamp, tz=timezone.utc)
        return dt.strftime('%Y-%m-%d %H:%M:%S')
    except Exception:
        return str(timestamp)


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def parse(url: str) -> ArticleResult:
    """
    Parse a WeChat article URL and return an ArticleResult.

    Uses wechat-article-parser if available, otherwise falls back to
    the stdlib-only implementation.
    """
    article = _try_library_parse(url)
    if article is not None:
        return article

    # Fallback
    print("[fallback] wechat-article-parser not available, using stdlib parser",
          file=sys.stderr)
    return _fallback_parse(url)


async def parse_async(url: str) -> ArticleResult:
    """Async wrapper around parse()."""
    return parse(url)


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────

def main():
    if len(sys.argv) < 2:
        print("Usage: python wechat_scraper.py <wechat_article_url> [output_file.md]")
        sys.exit(1)

    url = sys.argv[1]
    output_file = sys.argv[2] if len(sys.argv) > 2 else None

    print(f"Fetching: {url}", file=sys.stderr)
    result = parse(url)

    if not result.is_valid and not result.markdown:
        print("Error: could not extract article content", file=sys.stderr)
        sys.exit(1)

    # Print summary to stderr, markdown to stdout
    print(f"Title: {result.title}", file=sys.stderr)
    print(f"Author: {result.author}", file=sys.stderr)
    print(f"Published: {result.publish_time}", file=sys.stderr)
    print(f"Markdown length: {len(result.markdown)} chars", file=sys.stderr)
    print(f"Images: {len(result.images)} found", file=sys.stderr)
    print(f"Body SHA256: {result.body_sha256}", file=sys.stderr)
    print(f"Source: {'wechat-article-parser' if result.raw_html else 'stdlib fallback'}",
          file=sys.stderr)

    # Output markdown to stdout
    print(result.to_markdown())

    if output_file:
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(result.to_markdown())
        print(f"\nSaved to: {output_file}", file=sys.stderr)


if __name__ == '__main__':
    main()