# Web3 Wiki Backup Infrastructure

## GitHub Repos (Two Separate)
| Repo | URL | Content | Schedule |
|------|-----|---------|----------|
| Skills backup | `https://github.com/kozuelam9z/hermes-agent-backup` | tar.gz of `/opt/data/skills/` | Hourly |
| Wiki backup | `https://github.com/kozuelam9z/web3-payment-wiki` | Full wiki files | 4h (9am-9pm), 10h (outside) |

## Authentication
Classic PAT stored in `~/.netrc`:
```
machine github.com
login kozuelam9z
password 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
```

## Wiki Path
`/opt/data/wiki/` — initialized 2026-05-08

## Backup Scripts
- `/opt/data/scripts/skill-monitor.sh` — skills backup (hourly, tar.gz only)
- `/opt/data/scripts/wiki-monitor.sh` — wiki backup (4h/10h schedule, full file sync)

## Cron Jobs
- `skill-backup-hourly` — every hour, pushes tar.gz to hermes-agent-backup
- `wiki-backup-4h` — 9am, 1pm, 5pm, 9pm (within 9am-9pm window)
- `wiki-backup-10h` — 11pm (outside 9am-9pm window)

## Wiki Monitoring Strategy
- Wiki lives at `/opt/data/wiki/`
- Monitor script copies wiki files to `/opt/data/wiki-backup/` (git repo)
- Only the compressed tar.gz is pushed to the skills repo
- Full wiki file sync goes to the dedicated wiki repo